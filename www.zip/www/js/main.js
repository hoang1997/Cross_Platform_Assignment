// use when testing phone gap as will not get fired in browser
document.addEventListener("deviceready", setup, false);

