// use when testing phone gap as will not get fired in browser
document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
}

//keys
const key = "377d71bd31cf5b98d97de19c0f8c40b2";
const id = "11c71373";
const key2 = "dokpes34690cw9w43c4pb5xwermk8j";

//global variables
var foodArr = JSON.parse(localStorage.getItem("foodArr"));
var searchObject = JSON.parse(localStorage.getItem("searchObject"));
var recipeHtml = ""
var r = 0;
var nutritionInfo, ingredients, dietLabels, healthLabels, cautionInfo, groc, grocList;
var arr = [];
var favourites;
var grocArray;
var g = [];
localStorage.setItem("foodArr", JSON.stringify(arr));
var tutorial = false;
var tutorial2 = false;
var tutorial3 = false;
localStorage.setItem("tutorial-1", tutorial);
localStorage.setItem("tutorial-2", tutorial2);
localStorage.setItem("tutorial-3", tutorial3);

//* FRIDGE PAGE*//
//Creates fridge page
$(document).on('pagecreate', '#fridge', function () {
    //check to see if the array is empty, if it appends the foodArr with the value from the input
    if (foodArr != null) {
        appendFoodList();
    }
    else {
        //alert to the user that they need to add food
        navigator.notification.alert("Add Food");
    }
    // callback to when the add button is clicked
    $(document).on('click', '#addBtn', function (e) {
        //prevents the page from refreshing
        e.preventDefault();
        //gets the value of the input
        var food = $('#fInput').val();
        //check to see if the input is empty, if it is then alert the user 
        if (food == ' ') {
            navigator.notification.alert("Invalid Input");
        }
        else {
            //pushes the food item to the array
            arr.push(food);
            //store the array in local storage
            localStorage.setItem("foodArr", JSON.stringify(arr));
            //append the html global variable with html for list item
            html = '<li class="ui-li-static ui-body-inherit ui-last-child">' +
                '<div>' +
                '<h3>' + food + '</h3>' +
                '</div>' +
                '</li>';
            //append the food list with the html created previously
            $('.foodList').append(html);
        }
    });

    //callback for when the camera button is activated
    $(document).on('click', '#scanBtn', function (e) {
        //prevents page from refreshing
        e.preventDefault();
        
        //call the scan function from the cordova objects barcode scanner plugin
        cordova.plugins.barcodeScanner.scan(
            //if scan is successful
            function (result) {
                //tell the user that the scan was successfull
                navigator.notification.alert("We got a barcode\n" +
                    "Result: " + result.text + "\n" +
                    "Format: " + result.format + "\n" +
                    "Cancelled: " + result.cancelled);
                //make ajax call to barcode lookup API with barcode
                $.ajax({
                    //before the fetch is made
                    beforeSend: function () {
                        $.mobile.loading('show', {
                            text: "Please Wait",
                            textVisible: true,
                            theme: "a",
                        });
                    },
                    //when the call is finished
                    complete: function () { $.mobile.loading("hide"); },
                    //url of the call
                    url: "https://api.barcodelookup.com/v2/products?barcode=" + result.text + "&formatted=y&key=" + key2,
                    //type of data to be returned
                    dataType: 'json',
                    //if the API call is successful
                    success: function (myJson) {
                        //push the product name to the global array
                        arr.push(myJson.products["product_name"]);
                        //store the array in local storage
                        localStorage.setItem("foodArr", JSON.stringify(arr));
                        //add the html to the food list
                        html = '<li class="ui-li-static ui-body-inherit ui-last-child">' +
                            '<div>' +
                            '<h3>' + myJson.products[0].product_name + '</h3>' +
                            '</div>' +
                            '</li>';
                        $('.foodList').append(html);
                    }
                });
            },
            //if the scan is not successful//
            function (error) { navigator.notification.alert("Scanning failed: " + error); },

            //preferences for the barcode scanner.
            {
                preferFrontCamera: false, // iOS and Android
                showFlipCameraButton: true, // iOS and Android
                showTorchButton: false, // iOS and Android
                torchOn: false, // Android, launch with the torch switched on (if available)
                prompt: "Place a barcode inside the scan area", // Android
                resultDisplayDuration: 500, // Android, display scanned text for X ms. 0 suppresses it entirely, default 1500
                // formats: "QR_CODE, UPC_A, UPC_E", // default: all but PDF_417 and RSS_EXPANDED
                orientation: "landscape", // Android only (portrait|landscape), default unset so it rotates with the device
                disableAnimations: true, // iOS
                disableSuccessBeep: false // iOS and Android
            }
        );
    });
    //OVERLAY TUTORIAL FOR WHEN THE USER FIRST GOES ON THE FRIDGE PAGE//
    //check to see if the overlay has been clicked before
    if (localStorage.getItem("tutorial-1") == true) {
        //Manipulate the CSS for the overlay div to make the overylay dissapear
        $("#overlay-1").css({ "display": "none" });
    }
    //update the local storage when the user understands the tutorial
    $(document).on('click', '.understoodBtn', function (e) { 
        e.preventDefault();
        $(".overlay").css({ "display": "none" });
        var learnt = localStorage.getItem("tutorial-1");
        learnt = true;
        localStorage.setItem("tutorial-1", learnt);  
    });
});

/*RECIPE LIST PAGE*/
//when the page is created
$(document).on('pageshow', '#recipes', function () { 
    //when the recipe button gets clicked on 
    $(document).on('click', '.recipebtn', function (e) {
        //prevent the page from refreshing
        e.preventDefault();
        //reset the ID of the recipe
        r = '';
        //get the recipe number from the recipe card
        var rnumber = $(this).data('recipenum');
        //set the ID of the recipe number
        r = rnumber;
        //
        $('#recipe-box-detail').html('');
        $.mobile.changePage( "#sRecipe");
    });
    if (localStorage.getItem("tutorial-2") == true) {
        $("#overlay-2").css({ "display": "none" });
    } else {
        $("#overlay-2").css({ "display": "block" });
        console.log('overlay-2 appears');
    }
    $(document).on('click', '.understoodBtn', function (e) {
        e.preventDefault();
        $("#overlay-2").css({ "display": "none" });
        var learnt = localStorage.getItem("tutorial-2");
        console.log(learnt);
        learnt = true;
        localStorage.setItem("tutorial-2", learnt);
        console.log(localStorage.getItem("tutorial-2"));
    });
});
//*SPECIFIC RECIPE PAGE*//
//before the recipe page is shown
$(document).on("pagebeforeshow", "#sRecipe", function () { 
    var recipe = JSON.parse(localStorage.getItem("searchObject")).hits[r].recipe;
    //reset all variables
    ingredients = '';
    nutritionInfo = '';
    healthLabels = '';
    cautionInfo = '';
    grocList = '';
    //set ingredients html
    for (var i = 0; i < recipe.ingredients.length; i++) {
        ingredients += "<li>" + recipe.ingredients[i]["text"] + "</li>";
    }
    //set groceries list html
    for (var i = 0; i < localStorage.getItem("foodArr").length; i++) {
        for (var j = 0; j < recipe.ingredients.length; j++) {
            if (recipe.ingredients[j]["text"].includes(localStorage.getItem("foodArr")[i]) == false && grocList.includes(recipe.ingredients[j]["text"])== false) {
                grocList += '<div class="ui-checkbox"><label class="checkbox ui-btn -corner-all ui-btn-inherit ui-btn-icon-left ui-checkbox-off""><input type="checkbox" name="checkbox-0" data-cacheval="true">' + recipe.ingredients[j]["text"] + '</label></div>';
            }
        }
    }
    
    //set the nutrition info html
    nutritionInfo =
      recipe.totalNutrients.ENERC_KCAL["label"] +
      ": " +
      Math.round(recipe.totalNutrients.ENERC_KCAL["quantity"]) +
      recipe.totalNutrients.ENERC_KCAL["unit"] +
      "<br/>" +
      
      recipe.totalNutrients.FAT["label"] +
      ": " +
      Math.round(recipe.totalNutrients.FAT["quantity"]) +
      recipe.totalNutrients.FAT["unit"] + "<br/>" +
      recipe.totalNutrients.NA["label"] +
      ": " +
      Math.round(recipe.totalNutrients.NA["quantity"]) +
      recipe.totalNutrients.NA["unit"];
    
    //set the caution information html
    for (i = 0; i < recipe.cautions.length; i++) { 
        cautionInfo += "<p>" + recipe.cautions[i] + "</p>";
    }
});


$(document).on("pageshow", "#sRecipe", function () {
    //create the specific recipe page html
    var html =
                '<div class="recipe-box">' +
                "<h2>" +
                    JSON.parse(localStorage.getItem("searchObject")).hits[r].recipe["label"] +
                "</h2>" +
                "<button id='favBtn' class='ui-btn ui-shadow ui-corner-all'type='button'>Add to Favourites</button>" +
                "<div>" +
                "<img src=" +
                    JSON.parse(localStorage.getItem("searchObject")).hits[r].recipe["image"] +
                ' class="recipe-image" id="r-img" with="100%" height="100%">' +
                "</div>" +
                "<div>" +
                    "<h3>Nutritional Information</h3>" +
                    nutritionInfo +
                "</div>" +
                "<div>" +
                    "<h3>Cautions</h3>" +
                    cautionInfo +
                "</div>" +
                '<div class="ingredients-container">' +
                "<h3>Ingredients</h3>" +
                "<ul>" +
                    ingredients +
                "</ul>" +
                "</div>" +
                '<div class="steps-container">' +
                "<h3>Steps</h3>" +
                    "<a href=" + JSON.parse(localStorage.getItem("searchObject")).hits[r].recipe.url + ">Found Here</a>" +
                "</div>" +
                '<div class="groceries-container">' +
                '<div class="groceries-list">' +
                "<h2>Groceries List</h2>" +
                "<form>" +
                grocList + 
                "</form>" +
                    "<button id='grocBtn' class='ui-btn ui-shadow ui-corner-all'type='button'>Add Groceries</button>" +
                "</div>" +
                "</div>" +
                "</div>";
    //set the html 
    $('#recipe-box-detail').html(html);  

    //when the favourite button is clicked
    $(document).on('click', '#favBtn', function (e) {
        e.preventDefault();
        //create the html for the favourites recipe card 
        var recipe = '<div class="blog-card" style="margin-bottom: 15px">' +
            '<div class="blog-card-header">' +
            '<a data-recipenum="' + r + '" class="btn-one recipebtn"><img src="' + JSON.parse(localStorage.getItem("searchObject")).hits[r].recipe["image"] + '" width="100%" style="opacity:0.2"/></a>' +
            '<div class="blog-card-header-box" style="font-size:40px;top: 8px;left: 16px;"><h3>' + JSON.parse(localStorage.getItem("searchObject")).hits[r].recipe["label"] + '</h3></div>' +
            ' </div>' +
            '<div id="button-section">' +
            ' <button type="button" class=" ui-btn ui-shadow ui-corner-all"><a data-ajax="false" data-recipenum="' + r + '" class="btn-one recipebtn">View Recipe</a></button>' +
            '</div>' +
            '</div>';
        
        //check to see if the array is empty
        if (localStorage.getItem("favArray") != null) {
            //set the favourites variable to the favourites array
            favourites = localStorage.getItem("favArray");
        } else {
            favourites = '';
        }
        //add the recipe to the favourites variable
        favourites += recipe;
        //reset the local storage
        localStorage.setItem("favArray", favourites);
        //alert the user that the item has been saved
        navigator.notification.alert("Added " + JSON.parse(localStorage.getItem("searchObject")).hits[r].recipe["label"] + " to Favourites");
    });

    //when the add grocery button is clicked on, similar to favourites button above
    $(document).on('click', '#grocBtn', function (e) {
        e.preventDefault();
        if (localStorage.getItem("grocArray") != null) {
            grocArray = localStorage.getItem("grocArray");
        } else {
            grocArray = '';
        };
        grocArray += grocList;
        localStorage.setItem("grocArray", grocArray);
        navigator.notification.alert("Added to Groceries");
    });
});

/*FAVOURITES PAGE*/
$(document).on('pageshow', '#favourites', function (e) {
    e.preventDefault();
    $('.fav-container').html(' ');
    if (localStorage.getItem("favArray") != null) {
        $('.fav-container').html(localStorage.getItem("favArray"));
    } else {
        navigator.notification.alert("Nothing Saved Yet!");
        $.mobile.changePage('#fridge')
    }
});

/*GROCERIES PAGE*/
$(document).on('pageshow', '#groceries', function () {
    $('.groc-container').html(' ');
    if (localStorage.getItem("grocArray") != null) {
        $('.groc-container').html(localStorage.getItem("grocArray"));
    } else {
        navigator.notification.alert('No Grocery Lists Added Yet!');
        $.mobile.changePage('#fridge');
    }
    $(document).on('click', '#shopsBtn', function(){
        $.mobile.changePage('#shops')
    });
});

/*GESTURE FUNCTIONS FOR THE APP*/
//FRIDGE PAGE//
//Clears Fridge
$( document ).on( "swiperight", "#fridge", function(e) {
    e.preventDefault();
    navigator.notification.confirm(
        'Are you sure you want to CLEAR Fridge?', 
        function onConfirm() {
            localStorage.removeItem("foodArr");
            arr = [];
            $('#list').html(' ');
        },              
        'Clear Fridge',            
        'Close,Confirm'          
    );
});

//Goes to recipe page and makes call to recipe API
$( document ).on( "swipeleft", "#fridge", function(e) {
    e.preventDefault();
    if (JSON.parse(localStorage.getItem('foodArr')) == null) {
        navigator.notification.alert("Need to add food to view recipes!");
    } else {
        e.preventDefault();
        var url = fetchUrl(JSON.parse(localStorage.getItem('foodArr')));
        $.ajax({
            beforeSend: function () {
                $.mobile.loading('show', {
                    text: "Please Wait",
                    textVisible: true,
                    theme: "a",
                });
            },
            complete: function () { $.mobile.loading("hide"); },
            url: url,
            dataType: 'json',
            success: function (myJson) {
                localStorage.setItem("searchObject", JSON.stringify(myJson));
                recipeHtml = '';
                var i;
                for (i = 0; i < myJson.hits.length; i++) {
                    recipeHtml += '<div class="recipe-box">' +
                        '<div>' +
                        '<h3 class="recipeName">' + myJson.hits[i].recipe["label"] + '</h3>' +
                        '<img src=' + myJson.hits[i].recipe["image"] + ' class="recipe-image">' +
                        '</div>' +
                        '<div id="button-section">' +
                        '<button type="button" class="ui-btn ui-shadow ui-corner-all"><a data-ajax="false" data-recipenum="' + i + '" class="btn-one recipebtn">View Recipe</a></button>' +
                        '</div>' +
                        '</div>';
                }
                $('.recipe-container').html(recipeHtml);
            },
            error: function () {
                navigator.notification.alert("Failed to Find Recipes");
            }
        });
        $('.recipe-container').html(recipeHtml);
        $.mobile.changePage("#recipes");
    }
});

//SPECIFIC RECIPE PAGE//
//Goes back to recipes page
$( document ).on( "swiperight", "#sRecipe", function(e) {
    e.preventDefault();
    $.mobile.changePage("#recipes");
});

//RECIPES LIST PAGE//
//goes back to fridge page
$( document ).on( "swiperight", "#recipes", function(e) {
    e.preventDefault();
    $.mobile.changePage("#fridge");
});

//NEAREST SUPERMARKET PAGE
$(document).on("swiperight", "#shops", function (e) {
    e.preventDefault();
    $.mobile.changePage("#groceries");
});

//FAVOURITES PAGE
$(document).on("swiperight", "#favourites", function (e) {
    e.preventDefault();
    navigator.notification.confirm(
        'Are you sure you want to clear?',  // message
        function onConfirm2() {
            localStorage.removeItem("favArray");
            $('.fav-container').html(' ');
        },              // callback to invoke with index of button pressed
        'Clear Favourites',            // title
        'Close,Confirm'          // buttonLabels
    );
});

//GROCERIES PAGE//
$(document).on("swiperight", "#groceries", function (e) {
    e.preventDefault();
    navigator.notification.confirm(
        'Are you sure you want to clear?',  // message
        function onConfirm3() {
            localStorage.removeItem("grocArray");
            $('.groc-container').html(' ');
        },              
        'Clear Groceries',            
        'Close,Confirm'          
    );
});

$(document).on("swipeleft", "#groceries", function (e) {
    e.preventDefault();
    console.log('swipe left ')
    $.mobile.changePage("#shops");
});



/*SEPERATE FUNCTIONS*/
//Creates the API URL with the food items that the user inputted in the fridge
function fetchUrl(foodArr) {
    var url;
    //check to see if the food list is empty
    if (foodArr != null) {
        //loop through the first item of the food array
        for (var j = 0; j > foodArr[0].length; j++) {
            //check to see if there are any spaces and replace them with a +
            if (foodArr[0][j] == ' ') {
                foodArr[0][j] = "+";
            }
        }
        //loop through the rest of the food array
        var ingr = foodArr[0];
        for (var i = 1; i < foodArr.length; i++) {
            for (var j = 0; j > foodArr[i].length; j++) {
                if (foodArr[i][j] == ' ') {
                    foodArr[i][j] = "+";
                }
            }
            ingr += "+" + foodArr[i];
        }
    }
    //create the url for the API
    var url = 'https://api.edamam.com/search?q=' + ingr + '&app_id=11c71373&app_key=377d71bd31cf5b98d97de19c0f8c40b2';
    //return the url
    return url;
}

//Appends the food list from the foodArr 
function appendFoodList() {
    var i, html;
    $('.foodList').empty();
    //loop through the users food items list
    for (i = 0; i < foodArr.length; i++)
    {
        //set the html
        html = '<li class="ui-li-static ui-body-inherit ui-last-child">' +
            '<div>' +
            '<h3>' + foodArr[i] + '</h3>' +
            '</div>' +
            '</li>';
        //append the html
        $('.foodList').append(html)
    }
}

/*GEOLOCATION AND NEAREST SHOP PAGE */
var map, infoWindow, infoWindow2;
var request, service
var markers = [];
//Callback function for the API
function initMap() {
    //creates the initial map
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: -34.397, lng: 150.644 },
        zoom: 15
    });
    //creates the info window when the location is found
    infoWindow = new google.maps.InfoWindow;

    // Try HTML5 geolocation.
    if (navigator.geolocation) {
        //gets current position
        navigator.geolocation.getCurrentPosition(
            function (position) {
                //gets latitude and longitude of current location
                var pos = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                
                //sets the info windows positon
                infoWindow.setPosition(pos);
                infoWindow.setContent('Location found.');
                infoWindow.open(map);
                map.setCenter(pos);
                
                //requests information for supermarkets in the current location
                request = {
                    location: map.center,
                    radius: 3200,
                    types: ['supermarket']
                };
                
                //creates the second info window
                infoWindow2 = new google.maps.InfoWindow;
                
                //initate places service, with the current map as an argument
                service = new google.maps.places.PlacesService(map);
                
                //search for the supermarkets nearby and then calls the callback function when a shop is found
                service.nearbySearch(request, callback);
            },
            //handles location error 
            function () {
            handleLocationError(true, infoWindow, map.getCenter());
            }
        );
    } else {
        // Browser doesn't support Geolocation
        handleLocationError(false, infoWindow, map.getCenter());
    }   
}

//handles location error function
function handleLocationError(browserHasGeolocation, infoWindow, pos) {
    infoWindow.setPosition(pos);
    //tells the user that the geolocation is not supported
    infoWindow.setContent(browserHasGeolocation ?
        'Error: The Geolocation service failed.' :
        'Error: Your browser doesn\'t support geolocation.');
    infoWindow.open(map);
}

//callback when the supermarkets are found
function callback(results, status) {
    //check that everythings okay
    if (status == google.maps.places.PlacesServiceStatus.OK) {
        //loop through the results from the supermarket search
        for (var i = 0; i < results.length; i++) {
            //creates supermarket marker and then pushes into an array
            markers.push(createMarker(results[i]));
            //check to see if the supermarket is open or not
            var open = "open";
            //check to see if there are any opening hours information
            if (results[i].opening_hours != null) {
                //the supermarket is not open now
                if (results[i].opening_hours.open_now == false) {
                    //set the open variable to not open
                    open = "Currently Not Open";
                } else {
                    //set the open variable to open
                    open = "Currently Open";
                }
            } else {
                //if there are no opening hours information
                open = "No Opening Hours Found"
            }
            //create supermarket html for each supermarket found
            markersHtml += '<div class="shop-info">' +
                '<h3> ' + results[i].name + ': ' + open + '</h3>' +
                '<div class="shop-location"> Address: ' + results[i].vicinity + ' </div>' +
                '<div class="shop-rating" > Rating: ' + results[i].rating + ' </div>' +
                '</div><hr/>'
        }
    }
    //set the div to the supermarket html
    $('.shops-container').html(markersHtml);
}

//Creates markers for the map
var markersHtml = ' ';
function createMarker(place) {
    var placeloc = place.geometry.location;
    //creates the marker
    var marker = new google.maps.Marker({
        map: map,
        position: place.geometry.location
    })

    //event listener to when the marker is clicked on
    google.maps.event.addListener(marker, 'click', function () {
        infoWindow2.setContent(place.name);
        
        infoWindow2.open(map, this);
        
    });
    //returns the marker variable
    return marker;
}